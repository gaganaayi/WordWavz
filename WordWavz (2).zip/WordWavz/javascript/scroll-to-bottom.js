document.addEventListener('DOMContentLoaded', () => {
  const chatBox = document.querySelector('.chat-box');
  const scrollToBottomBtn = document.querySelector('.scroll-to-bottom');

  function scrollToBottom() {
    console.log("Button clicked: Scrolling to bottom");
    chatBox.scrollTop = chatBox.scrollHeight;
  }

  scrollToBottomBtn.addEventListener('click', scrollToBottom);

  chatBox.addEventListener('scroll', () => {
    if (chatBox.scrollTop < chatBox.scrollHeight - chatBox.clientHeight - 50) {
      scrollToBottomBtn.style.display = 'block';
    } else {
      scrollToBottomBtn.style.display = 'none';
    }
  });

  function checkButtonVisibility() {
    if (chatBox.scrollTop < chatBox.scrollHeight - chatBox.clientHeight - 50) {
      scrollToBottomBtn.style.display = 'block';
    } else {
      scrollToBottomBtn.style.display = 'none';
    }
  }

  // Initial check
  checkButtonVisibility();

  // Periodic check
  setInterval(checkButtonVisibility, 500);
});
