<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include_once "config.php";

$outgoing_id = $_SESSION['unique_id'];
$output = "";

$query = mysqli_query($conn, "SELECT * FROM users WHERE NOT unique_id = {$outgoing_id}");
while($row = mysqli_fetch_assoc($query)){
    $sql2 = "SELECT * FROM messages WHERE (incoming_msg_id = {$row['unique_id']}
            OR outgoing_msg_id = {$row['unique_id']}) AND (outgoing_msg_id = {$outgoing_id} 
            OR incoming_msg_id = {$outgoing_id}) ORDER BY msg_id DESC LIMIT 1";
    $query2 = mysqli_query($conn, $sql2);
    $row2 = mysqli_fetch_assoc($query2);
    $result = mysqli_num_rows($query2) > 0 ? $row2['msg'] : "No message available";
    $msg = strlen($result) > 28 ? substr($result, 0, 28) . '...' : $result;

    if (isset($row2['outgoing_msg_id'])) {
        $you = $outgoing_id == $row2['outgoing_msg_id'] ? "You: " : "";
    } else {
        $you = "";
    }

    $offline = $row['status'] == "Offline now" ? "offline" : "";
    $hid_me = $outgoing_id == $row['unique_id'] ? "hide" : "";

    $output .= '<a href="msg.php?user_id='. htmlspecialchars($row['unique_id']) .'">
                <div class="content">
                <img src="php/images/'. htmlspecialchars($row['img']) .'" alt="">
                <div class="details">
                    <span>'. htmlspecialchars($row['fname']) . " " . htmlspecialchars($row['lname']) .'</span>
                    <p>'. htmlspecialchars($you) . htmlspecialchars($msg) .'</p>
                </div>
                </div>
                <div class="status-dot '. htmlspecialchars($offline) .'"><i class="fas fa-circle"></i></div>
            </a>';
}
?>
