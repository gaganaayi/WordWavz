<?php
$hostname = "localhost";
$username = "wavz";
$password = "2984Wavz";
$dbname = "wwdb";

$conn = mysqli_connect($hostname, $username, $password, $dbname);
if(!$conn){
    echo "Database connection error: " . mysqli_connect_error();
}
?>