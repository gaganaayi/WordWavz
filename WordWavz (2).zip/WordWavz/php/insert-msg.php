<?php
session_start();
if(isset($_SESSION['unique_id'])){
    include_once "config.php";
    $outgoing_id = $_SESSION['unique_id'];
    $incoming_id = filter_input(INPUT_POST, 'incoming_id', FILTER_SANITIZE_NUMBER_INT);
    $message = filter_input(INPUT_POST, 'message', FILTER_SANITIZE_STRING);

    if(!empty($message)){
        $stmt = $conn->prepare("INSERT INTO messages (incoming_msg_id, outgoing_msg_id, msg, time, date) VALUES (?, ?, ?, CURRENT_TIME(), CURRENT_DATE())");
        $stmt->bind_param("iis", $incoming_id, $outgoing_id, $message);

        if($stmt->execute()){
            echo "Message sent";
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Message cannot be empty";
    }
} else {
    header("location: ../login.php");
}
?>
