<?php
session_start();
if(isset($_SESSION['unique_id'])){
    header("location: users.php");
}
?>

<?php
include_once "header.php";
echo '<link rel="icon" type="image/png" href="ww.ico">';
?>
<body>
<div class="wrapper">
    <section class="form signup">
        <header>WordWavz | CreationsFame</header>
        <form action="#" method="POST" enctype="multipart/form-data" autocomplete="off">
            <div class="error-text"></div>
            <div class="name-details">
                <div class="field input">
                    <label>First Name</label>
                    <input type="text" name="fname" placeholder="First name" required>
                </div>
                <div class="field input">
                    <label>Last Name</label>
                    <input type="text" name="lname" placeholder="Last name" required>
                </div>
            </div>

            <div class="field input">
                <label>Email Address</label>
                <input type="text" name="email" placeholder="Enter your email" required>
            </div>

            <div class="field input">
                <label>Password</label>
                <input type="password" name="password" placeholder="Enter new password" required>
                <i class="fas fa-eye"></i>
            </div>

            <div class="field image">
                <label for="image-upload" class="upload-label">
                    <i class="fas fa-upload"></i> Select Profile Image
                </label>
                <input type="file" id="image-upload" name="image" accept="image/x-png,image/gif,image/jpeg,image/jpg" required>
            </div>

            <div class="field text-toggle">
                <span id="toggle-social-status" style="font-weight: bold; color: #9CA3AF; cursor: pointer; font-size: 14px;">+ Add Social Status...</span>
            </div>

            <div id="social-status-fields" class="hidden">
                <div class="field input">
                    <label>Add Bio</label>
                    <input type="text" name="bio" placeholder="Enter bio">
                </div>
                <div class="field input">
                    <label>Instagram Link</label>
                    <input type="text" name="instagram" placeholder="Instagram link">
                </div>
                <div class="field input">
                    <label>LinkedIn Link</label>
                    <input type="text" name="linkedin" placeholder="LinkedIn link">
                </div>
                <div class="field input">
                    <label>Phone Number</label>
                        <input type="text" name="phone" placeholder="Phone number">
                </div>
                <div class="field input">
                    <label>Website Link</label>
                    <input type="text" name="website" placeholder="Website link">
                </div>
            </div>

            <div class="field button">
                <input type="submit" name="submit" value="Continue to Chat">
            </div>

        </form>
        <div class="link">Already signed up? <a href="login.php">Login now</a></div>
    </section>
</div>

<script src="javascript/pass-show-hide.js"></script>
<script src="javascript/signup.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const form = document.querySelector('form');
        const socialStatusFields = document.getElementById('social-status-fields');
        const toggleButton = document.getElementById('toggle-social-status');
        const phoneInput = form.querySelector('input[name="phone"]');

        // Ensure fields are hidden initially
        socialStatusFields.style.display = 'none';

        toggleButton.addEventListener('click', function() {
            if (socialStatusFields.style.display === 'none') {
                socialStatusFields.style.display = 'block';
                toggleButton.textContent = '- Hide Social Status...';
            } else {
                socialStatusFields.style.display = 'none';
                toggleButton.textContent = '+ Add Social Status...';
            }
        });

        // Validate URL and phone number formats on form submission
        form.addEventListener('submit', function(event) {
            const instagram = form.querySelector('input[name="instagram"]').value.trim();
            const linkedin = form.querySelector('input[name="linkedin"]').value.trim();
            const phone = phoneInput.value.trim();
            const website = form.querySelector('input[name="website"]').value.trim();

            const urlPattern = /^(https?:\/\/)?([a-z0-9-]+\.)+[a-z]{2,}(\/[a-z0-9-]+)*\/?$/i;
            const phonePattern = /^\d{10}$/;

            if (instagram && !urlPattern.test(instagram)) {
                alert('Please enter a valid Instagram link.');
                event.preventDefault();
                return;
            }

            if (linkedin && !urlPattern.test(linkedin)) {
                alert('Please enter a valid LinkedIn link.');
                event.preventDefault();
                return;
            }

            if (phone && !phonePattern.test(phone)) {
                alert('Please enter a valid 10-digit phone number.');
                event.preventDefault();
                return;
            }

            if (website && !urlPattern.test(website)) {
                alert('Please enter a valid website link.');
                event.preventDefault();
            }
        });

        // Prevent non-numeric characters in the phone number input field and limit to 10 digits
        phoneInput.addEventListener('input', function() {
            phoneInput.value = phoneInput.value.replace(/[^0-9]/g, '');
            if (phoneInput.value.length > 10) {
                phoneInput.value = phoneInput.value.slice(0, 10);
            }
        });
    });
</script>


</body>
</html>
