<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>WordWavz | CreationsFame</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>

    <!--
  <script>
  // URL obfuscation code
  (function() {
      // Function to generate a random string
      function generateRandomString(length) {
          const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
          let result = '';
          for (let i = 0; i < length; i++) {
              result += characters.charAt(Math.floor(Math.random() * characters.length));
          }
          return result;
      }

      // Function to update the URL
      function updateURL() {
          const randomPath = generateRandomString(12);
          const newURL = window.location.origin + '/' + randomPath;
          history.pushState({}, '', newURL);
      }

      // Call updateURL when the page loads
      window.addEventListener('load', updateURL);

      // Optional: Call updateURL when the user navigates through history
      window.addEventListener('popstate', updateURL);
  })();
  </script> -->
</head>