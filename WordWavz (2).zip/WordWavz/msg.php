<?php
session_start();
include_once "php/config.php";
if(!isset($_SESSION['unique_id'])){
    header("location: login.php");
}
?>
<?php
include_once "header.php";
echo '<link rel="icon" type="image/png" href="ww.ico">';
?>
<body>
<div class="wrapper">
    <section class="chat-area">
        <header>
            <?php
            $user_id = mysqli_real_escape_string($conn, $_GET['user_id']);
            $stmt = $conn->prepare("SELECT * FROM users WHERE unique_id = ?");
            $stmt->bind_param("s", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            if($result->num_rows > 0){
                $row = $result->fetch_assoc();
            } else {
                header("location: users.php");
            }
            $stmt->close();
            ?>
            <a href="users.php" class="back-icon"><i class="fas fa-arrow-left"></i></a>
            <img src="php/images/<?php echo htmlspecialchars($row['img']); ?>" alt="">
            <div class="details">
                <span><?php echo htmlspecialchars($row['fname']. " " . $row['lname']); ?></span>
                <p style="color: <?php echo $row['status'] === 'Active now' ? '#2ECC71' : '#E74C3C'; ?>; font-size: 14px; font-weight: bold;"><?php echo htmlspecialchars($row['status']); ?></p>
            </div>
        </header>
        <div class="chat-box">
        </div>
        <form action="#" class="typing-area">
            <input type="text" class="incoming_id" name="incoming_id" value="<?php echo htmlspecialchars($user_id); ?>" hidden>
            <input type="text" name="message" class="input-field" placeholder="Type a message here..." autocomplete="off">
            <button type="button" class="send-btn">
                <svg width="27px" height="27px" viewBox="0 -0.5 25 25" xmlns="http://www.w3.org/2000/svg">
                    <path fill="none" fill-rule="evenodd" clip-rule="evenodd" d="M18.455 9.8834L7.063 4.1434C6.76535 3.96928 6.40109 3.95274 6.08888 4.09916C5.77667 4.24558 5.55647 4.53621 5.5 4.8764C5.5039 4.98942 5.53114 5.10041 5.58 5.2024L7.749 10.4424C7.85786 10.7903 7.91711 11.1519 7.925 11.5164C7.91714 11.8809 7.85789 12.2425 7.749 12.5904L5.58 17.8304C5.53114 17.9324 5.5039 18.0434 5.5 18.1564C5.55687 18.4961 5.77703 18.7862 6.0889 18.9323C6.40078 19.0785 6.76456 19.062 7.062 18.8884L18.455 13.1484C19.0903 12.8533 19.4967 12.2164 19.4967 11.5159C19.4967 10.8154 19.0903 10.1785 18.455 9.8834V9.8834Z" stroke="#2ECC71" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </button>
            <button type="button" class="scroll-to-bottom">
                <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed">
                    <path d="M80-160v-280h360v280H80Zm0-360v-280h360v280H80Zm80-80h200v-120H160v120Zm560 440L520-360l56-56 104 103v-487h80v487l104-103 56 56-200 200Z"/>
                </svg>
            </button>
        </form>
    </section>
</div>
<script src="javascript/msg.js"></script>
<script src="javascript/scroll-to-bottom.js"></script>
</body>
</html>
