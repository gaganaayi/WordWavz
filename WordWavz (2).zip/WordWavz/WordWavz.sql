SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+05:30";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
                                          `msg_id` int(11) NOT NULL AUTO_INCREMENT,
                                          `incoming_msg_id` int(255) NOT NULL,
                                          `outgoing_msg_id` int(255) NOT NULL,
                                          `msg` varchar(1000) NOT NULL,
                                          `time` TIME NOT NULL,
                                          `date` DATE NOT NULL,
                                          PRIMARY KEY (`msg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
                                       `user_id` int(11) NOT NULL AUTO_INCREMENT,
                                       `unique_id` int(255) NOT NULL,
                                       `fname` varchar(255) NOT NULL,
                                       `lname` varchar(255) NOT NULL,
                                       `email` varchar(255) NOT NULL,
                                       `password` varchar(255) NOT NULL,
                                       `img` varchar(255) NOT NULL,
                                       `status` varchar(255) NOT NULL,
                                       `bio` TEXT,
                                       `instagram` VARCHAR(255) DEFAULT 'NA',
                                       `linkedin` VARCHAR(255) DEFAULT 'NA',
                                       `phoneNumber` VARCHAR(20) DEFAULT 'NA',
                                       `website` VARCHAR(255) DEFAULT 'NA',
                                       PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Stored procedure to insert into messages table
--

DELIMITER $$
CREATE PROCEDURE insert_message (
    IN p_incoming_msg_id INT,
    IN p_outgoing_msg_id INT,
    IN p_msg VARCHAR(1000)
)
BEGIN
    INSERT INTO messages (incoming_msg_id, outgoing_msg_id, msg, time, date)
    VALUES (p_incoming_msg_id, p_outgoing_msg_id, p_msg, CURRENT_TIME(), CURRENT_DATE());
END $$
DELIMITER ;

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
